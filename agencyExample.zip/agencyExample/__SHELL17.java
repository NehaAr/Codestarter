
public class __SHELL17 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
AgencyInterface.main(__bluej_param0);

}}
