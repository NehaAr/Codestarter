--Database for Assignment 3

drop table MovableResource
go
drop table ImovableResource
go

drop table  Student
go
drop table  Staff
go

drop table  Loan

go



drop table Course
go
drop table Privelege
go
drop table Reservation
go
drop table Resource
go
drop table  Member
go
drop table Location    
go
drop table Category
go



CREATE TABLE Location  (
    locationID     INT  identity(1,1) NOT NULL,
Room      Varchar(10),
building  Varchar(10),
campus    Varchar(10),
PRIMARY KEY (locationID),
);
go

CREATE TABLE  Category (
    categoryID    INT identity(1,1) NOT NULL,
	
  name      VARCHAR(20),
    Descriptions  varchar(50),
maxPeriodInHrs   int   Not Null,

PRIMARY KEY (categoryID),

);
go



CREATE TABLE  Privelege  (
    privelegeID     VARCHAR(10) NOT NULL,
	categoryId int NOT NULL,
name  Varchar(20),
description    Varchar(30),
numberOfResources INT,

PRIMARY KEY (privelegeID),
);
go


CREATE TABLE  Course  (
    courseID     VARCHAR(10) NOT NULL,
privelegeID  VARCHAR(10),
name  Varchar(20),
semesterOffered    Varchar(20),
yearOffered        varchar(20),
PRIMARY KEY (courseID),
FOREIGN KEY (privelegeID) REFERENCES  Privelege(privelegeID) ON UPDATE CASCADE ON
DELETE NO ACTION,
);
go

Create Table  Resource(
    resourceID      VARCHAR (10) NOT NULL,
reDescription   VARCHAR(50) NOT NULL, 
reStatus        VARCHAR(20) DEFAULT 'available' CHECK (reStatus IN 
('available', 'occupied', 'damaged'))NOT NULL, 
categoryID      INT,
locationID      INT,
PRIMARY KEY (resourceID),
FOREIGN KEY (categoryID) REFERENCES  Category(CategoryID) ON UPDATE CASCADE ON
DELETE NO ACTION,
FOREIGN KEY (locationID) REFERENCES  Location(LocationID)  ON UPDATE CASCADE 
ON DELETE NO ACTION 
);
go


CREATE TABLE  MovableResource (
    resourceID      VARCHAR (10) NOT NULL,
name            VARCHAR (20), 
moType          VARCHAR(20), 
moManufacturer  VARCHAR(30), 
moModel         VARCHAR(30), 
    moPrice         VARCHAR(15),
PRIMARY KEY (resourceID),
FOREIGN KEY (resourceID) REFERENCES  Resource(resourceID) ON UPDATE CASCADE ON
DELETE NO ACTION
);
go


CREATE TABLE  ImovableResource (
    resourceID      VARCHAR (10) NOT NULL,
	name varchar(10),
capacity            VARCHAR (20), 
PRIMARY KEY (resourceID),
FOREIGN KEY (resourceID) REFERENCES  Resource(resourceID) ON UPDATE CASCADE ON
DELETE NO ACTION
);
go


CREATE TABLE  Member (
    memberID      VARCHAR(15) NOT NULL, 
Name          VARCHAR(20) NOT NULL, 
DOB           DATETIME2 NOT NULL, 
TeleNum       INT,
Email         VARCHAR(20) NOT NULL, 
StartDate     DATE NOT NULL, 
Status        VARCHAR(8) DEFAULT 'active' CHECK (Status IN ('active', 
'expire')) NOT NULL, 
PRIMARY KEY (memberID),
);
go


CREATE TABLE  Student (
    memberID        VARCHAR(15) NOT NULL, 
stPoints        INT NOT NULL,
courseID        VARCHAR(10) NOT NULL,




PRIMARY KEY (memberID),
Foreign Key (memberID) references  Member(memberId) On Update Cascade On 
Delete NO ACTION,
Foreign Key (courseID) references  Course(courseId) On Update Cascade On 
Delete NO ACTION,


);
go

CREATE TABLE  Staff (
    memberID        VARCHAR(15) NOT NULL, 
staffPoints        INT,



PRIMARY KEY (memberID),
Foreign Key (memberID) references  Member(memberID) On Update Cascade On 
Delete NO ACTION,


);

CREATE TABLE  Reservation (
    reservationID        VARCHAR(15) NOT NULL, 
date       DATE,
resourceID Varchar(10) NOT NULL,
memberID   Varchar(15) NOT NULL,



PRIMARY KEY (reservationID),
Foreign Key (resourceID) references  Resource(resourceID) On Update Cascade On 
Delete NO ACTION,
Foreign Key (memberID) references  Member(memberID) On Update Cascade On 
Delete NO ACTION,

);
go


CREATE TABLE  Loan (
    loanID          int identity(1,1),
    dateTimeBorrowed DATE NOT NULL, 
dateTimeReturned DATE,
dateTimeDue      DATE NOT NULL,
resourceID       VARCHAR(10) NOT NULL,
memberID         VARCHAR(15) NOT NULL, 
PRIMARY KEY (loanID),
FOREIGN KEY (memberID) REFERENCES  Member(memberID) ON UPDATE CASCADE ON DELETE NO 
ACTION,
FOREIGN KEY (resourceID) REFERENCES  Resource(resourceID) ON UPDATE CASCADE ON 
DELETE NO ACTION,
    );
go

--Insert Data into Location
Insert into Location values('R1','B1','C1');
Insert into Location values('R2','B2','C2');
Insert into Location values('R3','B3','C3');
Insert into Location values('R4','B4','C4');

--Insert Data into Category
Insert into Category values('Accessory','for utility',72);
Insert into Category values('Books','for reading',72);
Insert into Category values('Rooms','for events',72);
Insert into Category values('Machine','for work',72);
Insert into Category values('Speaker','for work',72);
Insert into Category values('Camera','for work',72);

--Insert Data into Privelege
Insert into Privelege values('P101',1,'First Year','Privelege First Year',5);
Insert into Privelege values('P102',5,'Second Year','Privelege Second Year',5);
Insert into Privelege values('P103',3,'Third Year','Privelege Third Year',10);
Insert into Privelege values('P104',2,'Fourth Year','Privelege Fourth Year',10);

--Insert Data into Course
Insert into Course values('C1','P101','BTECH',1,2);

Insert into Course values('C2','P101','BTECH',1,2);
Insert into Course values('C3','P102','MCA',2,2);
Insert into Course values('C4','P103','MBA',1,2);

--Insert Data into Resource
Insert into Resource values('RS1','Accessory','occupied',1,1);
Insert into Resource values('RS2','Book','occupied',2,2);
Insert into Resource values('RS3','Book','occupied',2,2);
Insert into Resource values('RS4','Room','occupied',3,3);
Insert into Resource values('RS5','Room','available',3,3);
Insert into Resource values('RS6','Accessory','damaged',1,1);
Insert into Resource values('RS7','Book','available',2,2);
Insert into Resource values('RS8','Room','occupied',3,3);
Insert into Resource values('RS9','Room','available',3,3);
Insert into Resource values('RS10','Accessory','occupied',1,1);
Insert into Resource values('RS11','Book','occupied',2,2);
Insert into Resource values('RS12','Room','occupied',3,3);
Insert into Resource values('RS13','Room','occupied',3,3);
Insert into Resource values('RS14','Camera','occupied',6,3);
--Insert Data into MovableResource
Insert into MovableResource values('RS1','Pen','Parker','Parker Inc.','MD123',10);
Insert into MovableResource values('RS2','Book','Database Systems','Pearson','ISBN123',250);
Insert into MovableResource values('RS3','Book','Programming With C','Pearson','ISBN456',350);
Insert into MovableResource values('RS6','Marker','WhiteSolution','Zipro','MD567',67);
Insert into MovableResource values('RS14','Camera','WhiteSolution','Zipro','MD569',670);

--Insert Data into ImovableResource
Insert into ImovableResource values('RS4','Room1','500');
Insert into ImovableResource values('RS5','Room2','600');
Insert into ImovableResource values('RS8','Lab1','700');
Insert into ImovableResource values('RS12','Lab2','800');

--Insert Data into Member
Insert into Member values('M1','Neha','1999-09-15',998877777,'m1@gmail.com','2021-05-13','active');
Insert into Member values('M2','Neha1','1992-08-5',567890345,'m2@gmail.com','2017-05-12','expire');
Insert into Member values('M3','Neha2','1999-07-15',876543210,'m3@gmail.com','2021-01-13','active');
Insert into Member values('M4','Neha3','1999-06-15',988554411,'m4@gmail.com','2022-01-13','active');
Insert into Member values('M5','Neha4','1999-09-15',998887777,'m5@gmail.com','2021-05-13','active');
Insert into Member values('M6','Neha5','1992-08-5',567897745,'m6@gmail.com','2018-02-12','expire');
Insert into Member values('M7','Neha6','1999-07-15',876578210,'m7@gmail.com','2021-01-13','active');
Insert into Member values('M8','Neha7','1999-06-15',988574411,'m8@gmail.com','2022-01-13','active');
Insert into Member values('M9','Neha8','1999-05-15',876568210,'m7@gmail.com','2021-01-13','active');
Insert into Member values('M10','Neha9','1999-02-15',988564411,'m8@gmail.com','2022-01-13','active');

--Insert Data into Student
Insert into Student values('M1',20,'C1');
Insert into Student values('M3',30,'C1');
Insert into Student values('M4',40,'C3');
Insert into Student values('M5',40,'C4');

--Insert Data into Staff
Insert into Staff values('M7',20);
Insert into Staff values('M8',30);
Insert into Staff values('M9',40);
Insert into Staff values('M10',40);
Insert into Staff values('M1',40);
Insert into Staff values('M2',40);

--Insert Data into Loan
Insert into Loan values('2022-04-12',NULL,'2022-04-15','RS2','M1');
Insert into Loan values('2022-04-12',NULL,'2022-04-15','RS3','M2');
Insert into Loan values('2022-04-12',NULL,'2022-04-15','RS14','M2');
Insert into Loan values('2022-04-11',NULL,'2022-04-15','RS14','M2');
Insert into Loan values('2022-03-11','2022-03-16','2022-03-14','RS7','M9');
Insert into Loan values('2022-01-02','2022-01-06','2022-01-05','RS9','M10');

--Insert Data into Reservation
Insert into Reservation values('RE1','2022-04-12','RS2','M9');
Insert into Reservation values('RE2','2022-04-11','RS3','M10');
Insert into Reservation values('RE3','2021-05-01','RS4','M1');
Insert into Reservation values('RE4','2021-04-19','RS8','M2');
Insert into Reservation values('RE5','2022-04-19','RS11','M2');
Insert into Reservation values('RE6','2021-04-19','RS12','M2');
Insert into Reservation values('RE7','2021-05-01','RS4','M3');
Insert into Reservation values('RE8','2022-06-05','RS5','M4');
Insert into Reservation values('RE9','2021-09-19','RS8','M5');
Insert into Reservation values('RE10','2021-09-19','RS4','M5');


--Query1
select Name , courseID from Member m , Student s where m.memberID=s.memberID AND s.courseID='C1';

--Query 2

select numberOfResources from Privelege p , Category c , Student s , Course co where s.courseID=co.courseID
AND co.privelegeID=p.privelegeID AND p.categoryID=c.categoryID AND c.name='Speaker' AND co.courseID='C3';

--Query 3
select r.memberID ,r.date, m.Name,m.TeleNum,count(r.reservationID) as TotalNumberOfReservations from Member m , Staff st,Reservation r
where m.memberID=st.memberID AND st.memberID=r.memberID   group by r.memberID  , m.Name , m.TeleNum , r.date having r.memberID='M2' AND YEAR(r.date)='2021';

--Query 4
select Distinct m.name,l.resourceID from Member m , Student s , Category c, Loan l ,Resource r, MovableResource mr where l.resourceID=(select resourceID from   MovableResource  where reDescription='Camera' and moModel='MD569') and l.memberID=m.memberID;

--Query5
Select mr.resourceID,mr.name
from MovableResource mr, Loan l
where mr.resourceID = l.resourceID 
Group by mr.resourceID, mr.name
Having count(l.resourceID) >=
all (select count (*)
from Loan l where month(dateTimeBorrowed)=month(CURRENT_TIMESTAMP)

Group by l.resourceID
)

--Query6

select   i.name,re.date ,count(r.reDescription) as NoOfRoomsBooked from  Resource r , ImovableResource i , Reservation re where re.resourceID=i.resourceID and i.resourceID=r.resourceID and re.date IN('2021-09-19','2022-06-05','2021-05-01') and i.name='Room1' group by  i.name,re.date;