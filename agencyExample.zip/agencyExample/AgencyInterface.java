// 7/3/2022 Name-Neha Id- C3391165
import java.util.*;

public class AgencyInterface 
{
    public static void main (String[] args) 
    {
       Scanner console = new Scanner(System.in);
       Couple c = new Couple();
       int      age1,age2,end;
       String   name1,name2;
       
       do {
           System.out.print("first person: "); 
           System.out.print("name: "); 
           name1 = console.next();
           System.out.print("age: "); 
           age1 = console.nextInt();
           
           

           System.out.print("second person: "); 
           System.out.print("name: "); 
           name2 = console.next();
           System.out.print("his age: "); 
           age2 = console.nextInt();
           c.addData(name1,age1,name2,age2);

           System.out.println("********************");
           System.out.println(c.test(0)); 
           c.inputAge(c,0);
           System.out.println("********************");
           System.out.print("Quit? (0)yes (1)no: "); 
           end = console.nextInt();
           }
       while (end!=0);
       }
}