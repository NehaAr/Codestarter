import java.util.*;

public class Couple
{
    final private int MAX = 5;
    private Person[] p1,p2;
    private int total;
//--------------------------------------------------------------------------------------
    public Couple()
    {  
         this.p1  = new Person[MAX];
         this.p2 = new Person[MAX];
         
         total = 0;
        
    }
//--------------------------------------------------------------------------------------
    public void addData(String name1, int age1, String name2, int age2)
    {   System.out.print("Nehuuu"+total);
        this.p1[total] = new Person();
        this.p2[total] = new Person();
        setData1(p1[total],name1,age1);
        setData1(p2[total],name2,age2);
        total++;
        System.out.print("Neha"+total);
    }
    private void setData1(Person p, String name, int age)
    {
            p.setName(name);
            p.setAge(age);
            System.out.print(name);
            System.out.print(age);
            System.out.print(p1[1]);
    }
//------
    public static int inputAge(Couple c, int current) 
    {Scanner console = new Scanner(System.in);
     int      age1,age2,end;
     String   name1,name2; 
     
     if(c.p1[current].getAge() < 18)
        {  System.out.print("Age of First Person is less than 18");
           System.out.print("first person: "); 
           System.out.print("name: "); 
           name1 = console.next();
           System.out.print("age: "); 
           age1 = console.nextInt();
           c.setData1(c.p1[current],name1,age1);
        }
      
     if(c.p2[current].getAge() < 18)
        {  System.out.print("Age of Second Person is less than 18");
           System.out.print("Second person: "); 
           System.out.print("name: "); 
           name2 = console.next();
           System.out.print("age: "); 
           age2 = console.nextInt();
           c.setData1(c.p2[current],name2,age2);
        }
        return(4);
    } 
   // --------------------------------------------------------------------------------    
    public String test(int current)
    {  System.out.print(current);
       
       if (current!=-1)
       {
        
        if (p1[current].getAge() < p2[current].getAge()) return("GOOD FOR "+p2[current].getName()+"!");
        else                                              return("GOOD FOR "+p1[current].getName()+"!");
        
        
       }
       
       
       return "error";
   }
    public String display(int current)
    {
        return("p1: "+p1[current].getName()+","+p1[current].getAge()+"\np2:"+p2[current].getName()+","+p2[current].getAge());
    }
}